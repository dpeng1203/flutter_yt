class ModelDialogs<T> {
  String type = 'ok';
  T message;
  ModelDialogs({this.type, this.message});
}
