import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  // 单独改变状态栏颜色
  SystemChrome.setSystemUIOverlayStyle(uiStyle);
  runApp(MyApp());
}

SystemUiOverlayStyle uiStyle = SystemUiOverlayStyle.light.copyWith(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark);

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '数联宝',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: WebviewPage(),
    );
  }
}

class WebviewPage extends StatefulWidget {
  @override
  _WebviewPageState createState() => _WebviewPageState();
}

class _WebviewPageState extends State<WebviewPage> {
  DateTime _lastPressedAt; //上次点击时间
  final flutterWebViewPlugin = FlutterWebviewPlugin();

  // On urlChanged stream
  StreamSubscription<String> _onUrlChanged;

  //退出app
  // ignore: missing_return
  Future<bool> exitApp() {
    if (_lastPressedAt == null ||
        DateTime.now().difference(_lastPressedAt) > Duration(seconds: 2)) {
      showToast("再按一次退出应用！");
      _lastPressedAt = DateTime.now();
      return Future.value(false);
    } else {
      SystemChannels.platform.invokeMethod('SystemNavigator.pop');
    }
  }

  void showToast(
    String text, {
    gravity: ToastGravity.CENTER,
    toastLength: Toast.LENGTH_SHORT,
  }) {
    Fluttertoast.showToast(
      msg: text,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.grey[900],
      // 灰色背景
      fontSize: 16.0,
    );
  }

  @override
  void initState() {
    super.initState();
//    flutterWebViewPlugin.close();

    // Add a listener to on url changed
    _onUrlChanged =
        flutterWebViewPlugin.onUrlChanged.listen((String url) async {
      if (url.contains('taobao:') ||
          url.contains('jd:') ||
          url.contains('imeituan:') ||
          url.contains('pinduoduo:') ||
          url.contains('	weixin:') ||
          url.contains('openapp.jdmobile:') ||
          url.contains('vipshop:')) {
        await flutterWebViewPlugin.stopLoading();
        await flutterWebViewPlugin.goBack();
        print(url);
        if (await canLaunch(url)) {
          showToast("打开应用！");
          await launch(url);
        } else {
          showToast("未安装此应用！");
//          throw 'Could not launch $url';
        }
      }
    });
  }

  @override
  void dispose() {
    _onUrlChanged.cancel();
    flutterWebViewPlugin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      child: Scaffold(
        body: Center(
          child: WebviewScaffold(
//            url: "http://www.soupjian.work/#/recommend",
            url: "http://mg.2qzs.com/slApp/index.html#/",
            appBar: PreferredSize(
              preferredSize: Size.fromHeight(
                  MediaQueryData.fromWindow(window).padding.top),
              child: SafeArea(
                top: true,
                child: Offstage(),
              ),
            ),
//            javascriptChannels: jsChannels,
//            mediaPlaybackRequiresUserGesture: false,
//            withZoom: true,
//            withLocalStorage: true,
//            hidden: true,
            //JS执行模式 是否允许JS执行
//            javascriptMode: JavascriptMode.unrestricted,
//            onWebViewCreated: (controller) {
//              _controller = controller;
//            },
//            onPageFinished: (url) {
//              _controller.evaluateJavascript("document.title").then((result){
//                setState(() {
//                  _title = result;
//                });
//              }
//              );
//            },
          ),
        ),
      ),
      onWillPop: () {
        Future<bool> canGoBack = flutterWebViewPlugin.canGoBack();
        canGoBack.then((str) {
          if (str) {
            flutterWebViewPlugin.goBack();
          } else {
//              Navigator.of(context).pop();
            this.exitApp();
          }
        });
      },
    );
  }
}
